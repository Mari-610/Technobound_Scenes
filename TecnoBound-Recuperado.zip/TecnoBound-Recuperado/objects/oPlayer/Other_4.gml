if (room != Menu) {
    x = room_width / 2;
    y = room_height / 2;
}

if (room != rOficina) {
    view_enabled = true;
    view_visible[0] = true;

    var _Largura_Camera = room_width;
    var _Altura_Camera = room_height;

    if (room == Room_0 || room == Room_10 || room == Room_20) {
        _Largura_Camera = 400;
        _Altura_Camera = 200;
    }

    var _Camera = camera_create_view(
        0,
        0,
        _Largura_Camera,
        _Altura_Camera,
        0,
        id,
        -1,
        -1,
        _Largura_Camera / 2,
        _Altura_Camera / 2
    );

    view_camera[0] = _Camera;
}