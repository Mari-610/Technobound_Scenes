if (!encaixada && instance_exists(Teclas)) {
    if (Teclas.encaixada) {
        arrastando = true;

        offsetX = x - mouse_x;
        offsetY = y - mouse_y;
    }
}