if (global.pedidoAceito == 0) {
    room_goto(rConclusao);
}