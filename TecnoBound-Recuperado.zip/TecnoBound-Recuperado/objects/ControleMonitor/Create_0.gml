monitorCompleto = false;
mensagemExibida = false;