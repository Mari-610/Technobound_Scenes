verificacaoFeita = false;
montagemCorreta = false;