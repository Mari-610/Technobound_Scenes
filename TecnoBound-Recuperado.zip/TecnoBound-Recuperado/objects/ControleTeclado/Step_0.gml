if (instance_exists(Base_teclado)
&& instance_exists(Teclas)
&& instance_exists(Grade)) {

    tecladoCompleto =
        Base_teclado.encaixada
        && Teclas.encaixada
        && Grade.encaixada;

    if (tecladoCompleto && !mensagemExibida) {
        show_debug_message("Teclado montado com sucesso!");
        mensagemExibida = true;
    }
}