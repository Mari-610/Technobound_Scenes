tecladoCompleto = false;
mensagemExibida = false;