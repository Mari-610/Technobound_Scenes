arrastando = false;
offsetX = 0;
offsetY = 0;